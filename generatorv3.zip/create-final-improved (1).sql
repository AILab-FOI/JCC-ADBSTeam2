CREATE TABLE Country(
    id_country VARCHAR(3) PRIMARY KEY NOT NULL,
    country_name VARCHAR(45) NOT NULL
);

CREATE TABLE City(
    postal_code VARCHAR(5) NOT NULL,
    id_country VARCHAR(3) REFERENCES Country(id_country) NOT NULL,
    city_name VARCHAR(20) NOT NULL,
    PRIMARY KEY(postal_code, id_country)
);

CREATE TABLE Users(
    user_name VARCHAR(50) PRIMARY KEY NOT NULL,
    postal_code VARCHAR(5) NOT NULL,
    id_country VARCHAR(3) NOT NULL,
    password_hash VARCHAR(100) NOT NULL,
    name VARCHAR(40) NOT NULL,
    surname VARCHAR(40) NOT NULL,
    address VARCHAR(50),
    ban BOOLEAN NOT NULL,
    ProfilePicture BYTEA,
	last_online TIMESTAMP, 

    CONSTRAINT PFK
        FOREIGN KEY (postal_code, id_country)
        REFERENCES City(postal_code, id_country)
);

CREATE TABLE Account_status(
    code INTEGER PRIMARY KEY NOT NULL,
    description TEXT NOT NULL
);

CREATE TABLE Logs(
    log_id SERIAL PRIMARY KEY NOT NULL,
    user_name VARCHAR(50) REFERENCES Users(user_name) NOT NULL,
    date_time TIMESTAMP NOT NULL,
    code INTEGER NOT NULL REFERENCES Account_status(code)
);

CREATE TYPE LSPAN AS (
	created TIMESTAMP,
	deleted TIMESTAMP
);

CREATE TABLE Post(
    post_id SERIAL PRIMARY KEY NOT NULL,
    user_name VARCHAR(50) REFERENCES Users(user_name) NOT NULL,
    post_title VARCHAR(100) NOT NULL,
    post_description TEXT NOT NULL,
    LifeSpan LSPAN,
    date_edited TIMESTAMP Array,
    visible BOOLEAN NOT NULL,
    satus TEXT,
    PostPictures BYTEA Array
);

CREATE TABLE Report_code(
    code INTEGER PRIMARY KEY NOT NULL,
    description TEXT NOT NULL
);

CREATE TABLE Report_log(
    report_log_id SERIAL PRIMARY KEY NOT NULL,
    post_id INTEGER REFERENCES Post(post_id) NOT NULL,
    created_at TIMESTAMP NOT NULL,
    code INTEGER REFERENCES Report_code(code) NOT NULL
);

CREATE TABLE Permission(
    permission_type SERIAL PRIMARY KEY NOT NULL,
    permission_name VARCHAR(40) NOT NULL,
    description TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL
);

CREATE TABLE Role(
    role_id SERIAL PRIMARY KEY NOT NULL,
    role_id_inhe integer REFERENCES Role(Role_id),
    role_name VARCHAR(20) NOT NULL,
    created_at TIMESTAMP NOT NULL
);

CREATE TABLE Role_permission(
    permission_type INTEGER REFERENCES Permission(permission_type) NOT NULL,
    role_id INTEGER REFERENCES Role(role_id) NOT NULL,
    PRIMARY KEY (permission_type, role_id)
);

CREATE TABLE Users_roles(
    user_name VARCHAR(50) REFERENCES Users(user_name) NOT NULL,
    role_id INTEGER REFERENCES Role(role_id) NOT NULL,
    assigned_at TIMESTAMP NOT NULL,
    expire_at TIMESTAMP,
    PRIMARY KEY (user_name, role_id, assigned_at)
);

CREATE TABLE Users_permission(
    user_name VARCHAR(50) REFERENCES Users(user_name) NOT NULL,
    permission_type INTEGER REFERENCES Permission(permission_type) NOT NULL,
    assigned_at TIMESTAMP NOT NULL,
    expire_at TIMESTAMP,
    TablesManagment boolean,
    PRIMARY KEY(user_name, permission_type, assigned_at)
);
