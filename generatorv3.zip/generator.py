import random
import csv
import string
import hashlib
from datetime import datetime, timedelta

def createString(num):
    random_string = ''
    
    random_integer = random.randint(65, 90)
    random_string += (chr(random_integer))

    for _ in range(num):
        random_integer = random.randint(97, 97 + 26 - 1)
        random_string += (chr(random_integer))
    return random_string

userNames = []

with open('Usernames.csv', mode ='r')as file:
    csvFile = csv.reader(file)
    userNamesCount = 0
    for lines in csvFile:
        userNamesCount+=1
        userNames.append(lines)

blogTitles = []
with open('Blog titles.csv', mode ='r')as file:
    csvFile = csv.reader(file)
    titlesCount = 0
    for lines in csvFile:
        titlesCount+=1
        blogTitles.append(lines[0])


def createUserName():
    return userNames[random.randint(1,userNamesCount)-1][0] + str(random.randint(1, 99999))

with open('People.csv', mode ='r')as file:
    csvFile = csv.reader(file)
    namesCount = 0
    people_names = []
    for lines in csvFile:
        namesCount+=1
        people_names.append(lines)

with open('Last_names.csv', mode ='r')as file:
    csvFile = csv.reader(file)
    lastNamesCount = 0
    people_lastnames = []
    for lines in csvFile:
        lastNamesCount+=1
        people_lastnames.append(lines)

with open('Usernames.csv', mode ='r')as file:
    csvFile = csv.reader(file)
    userNamesCont = 0
    for lines in csvFile:
        userNamesCont+=1
        final = str(lines[0])
        userNames.append(final)

def randomName(gender):
    if(gender):
        return people_names[random.randint(2,namesCount-2)][3]
    else:
        return people_names[random.randint(2,namesCount-2)][1]

def randomSurname():
    return people_lastnames[random.randint(2,lastNamesCount-2)][0]


with open('Countries with iso codes.csv', mode ='r')as file:
    csvFile = csv.reader(file)
    countriesCount = 0
    countries = []
    for lines in csvFile:
        countriesCount+=1
        countries.append(lines)

def createPassword(length):
    letters_and_digits = string.ascii_letters + string.digits
    result_str = ''.join((random.choice(letters_and_digits) for i in range(length)))
    hashed_string = hashlib.sha256(result_str.encode('utf-8')).hexdigest()
    return hashed_string

def createTimeStamp(min, max):
    ts = random.randint(min,max)
    dt = datetime.fromtimestamp(ts)
    return dt

file1 = open("insert.sql", "w")


# Filling table Country
for i in range(1, countriesCount):
    file1.write("INSERT INTO Country VALUES('")
    file1.write(countries[i][2][5:8] + "', '" + countries[i][0])
    file1.write("');\n")


combination = []
# Filling table City
for i in range(1, 10000):
    file1.write("INSERT INTO City VALUES(")
    num = random.random()
    postal = int(random.randint(1,99999))
    id_state = int(random.randint(2, countriesCount))
    combination.append([postal, countries[id_state-1][2][5:8]])
    file1.write("'" + str(postal) + "' , '" + countries[id_state-1][2][5:8] + "' ,'" + createString(19) + "'")
    file1.write(");\n")


# Filling table User
finalUsernames = []
for i in range(1, 10000):
    file1.write("INSERT INTO Users VALUES('")
    activeUsername = createUserName()
    finalUsernames.append(activeUsername)
    file1.write(activeUsername+"', '")
    num = random.randint(1, len(combination)-1)
    if(random.randint(0,1)):
        ban = 'TRUE'
    else:
        ban='FALSE'
    if(random.randint(0,1)):
        status = 'TRUE'
    else:
        status='FALSE'
    if(random.randint(0,1)):
        gender = True
    else:
        gender=False
    
    file1.write(
        str(combination[num][0]) 
        + "', '" 
        + str(combination[num][1]) 
        + "', '" 
        + createPassword(random.randint(8,32)) 
        + "', '" 
        + randomName(gender) 
        + "', '" 
        + randomSurname() 
        + "', '"
        + createString(29) 
        + str(random.randint(1,255)) 
        + "','" + status + "','" + ban + "' , NULL")
    file1.write(");\n")

# Filling table Post
for i in range(1, 50001):
    file1.write("INSERT INTO Post VALUES(DEFAULT, '")
    created = createTimeStamp(1600000000, 1650000000)
    if(random.randint(0,5)):
        modified = 'NULL'
    else:
        time_change = timedelta(seconds=random.randint(50,100000000))
        modified = "'{" + str(created+time_change) + "}'"

    if(random.randint(0,15)):
        deleted = 'NULL'
    else:
        time_change = timedelta(seconds=random.randint(50,100000000))
        deleted = "'" + str(created+time_change) + "'"

    if(random.randint(0,3)):
        visible = 'TRUE'
    else:
        visible = 'FALSE'

    if(random.randint(0,20)):
        stat = 'NULL'
    else:
        stat = "'" + createString(random.randint(19,40)) + "'"

    file1.write(finalUsernames[random.randint(0, len(finalUsernames)-1)] + "', '" + str(blogTitles[random.randint(0,len(blogTitles)-1)]) + "', '" + createString(random.randint(3,1000)) + "', ('" + str(created) + "'," + str(deleted) + "), " + str(modified) + ", '" + visible + "', " + stat + ", NULL")
    file1.write(");\n")


# Filling table Account_status
#for i in range(1, 101):
#    file1.write("INSERT INTO Account_status VALUES(")
#    file1.write(str(i) + ", '" + createString(99) + "'")
#    file1.write(");\n")

file1.write("INSERT INTO Account_status VALUES(1, 'Log in');\n")
file1.write("INSERT INTO Account_status VALUES(2, 'Log out');\n")
file1.write("INSERT INTO Account_status VALUES(3, 'Log in failed');\n")
file1.write("INSERT INTO Account_status VALUES(4, 'Post created');\n")
file1.write("INSERT INTO Account_status VALUES(5, 'Post deleted');\n")
file1.write("INSERT INTO Account_status VALUES(6, 'Post reported');\n")
file1.write("INSERT INTO Account_status VALUES(7, 'Role assigned to the user');\n")
file1.write("INSERT INTO Account_status VALUES(8, 'Role removed from the user');\n")
file1.write("INSERT INTO Account_status VALUES(9, 'Permission assigned to the user');\n")
file1.write("INSERT INTO Account_status VALUES(10, 'Permission removed from the user');\n")

# Filling table Log
for i in range(1, 50001):
    file1.write("INSERT INTO Logs VALUES(DEFAULT, '")
    file1.write(finalUsernames[random.randint(0, len(finalUsernames)-1)] + "', '" + str(createTimeStamp(1600000000, 1650000000)) + "', " + str(random.randint(1,10)))
    file1.write(");\n")

# Filling table Report_code
#for i in range(1, 20):
#    file1.write("INSERT INTO Report_code VALUES(")
#    file1.write(str(i) + ", '" + createString(99) + "'")
#    file1.write(");\n")

file1.write("INSERT INTO Report_code VALUES(1, 'Misleading or a scam');\n")
file1.write("INSERT INTO Report_code VALUES(2, 'Sexually inappropriate');\n")
file1.write("INSERT INTO Report_code VALUES(3, 'Offensive');\n")
file1.write("INSERT INTO Report_code VALUES(4, 'Violent');\n")
file1.write("INSERT INTO Report_code VALUES(5, 'Spam');\n")
file1.write("INSERT INTO Report_code VALUES(6, 'False information');\n")
file1.write("INSERT INTO Report_code VALUES(7, 'Political candidate or an issue');\n")
file1.write("INSERT INTO Report_code VALUES(8, 'Prohibited content');\n")
file1.write("INSERT INTO Report_code VALUES(9, 'Other');\n")




# Filling table Report_log
for i in range(1, 1001):
    file1.write("INSERT INTO Report_log VALUES(DEFAULT, ")
    file1.write(str(random.randint(1,50000)) + ", '" + str(createTimeStamp(1600000000, 1650000000)) + "', " + str(random.randint(1,9)))
    file1.write(");\n")


# Filling table Role
for i in range(1, 501):
    file1.write("INSERT INTO Role VALUES(DEFAULT, ")
    file1.write(str(random.randint(1,i)) + ", '" + createString(19) + "', '" + str(createTimeStamp(1600000000, 1650000000)) + "'")
    file1.write(");\n")


# Filling table Permission
for i in range(1, 501):
    file1.write("INSERT INTO Permission VALUES(DEFAULT, '")
    file1.write(createString(39) + "', '" + createString(99) + "','" + str(createTimeStamp(1600000000, 1650000000)) + "'")
    file1.write(");\n")


# Filling table Role_permission
for i in range(1, 101):
    num1 = random.randint(1,100)
    num2 = random.randint(1,100)
    file1.write("INSERT INTO Role_permission VALUES(")
    file1.write(str(num1) + ", " + str(num2) +"")
    file1.write(");\n")


# Filling table User_roles
for i in range(1, 101):
    num1 = random.randint(1,100)
    num2 = random.randint(1,100)

    if(random.randint(0,15)):
        expire_at = 'NULL'
    else:
        expire_at = "'" + str(createTimeStamp(1600000000, 1650000000)) + "'"
    file1.write("INSERT INTO Users_roles VALUES('")
    file1.write(finalUsernames[random.randint(0, len(finalUsernames)-1)]+ "', " + str(random.randint(1,100)) +", '" + str(createTimeStamp(1600000000, 1650000000)) + "', " + expire_at)
    file1.write(");\n")


# Users_permissions

for i in range(1, 101):
    num1 = int(random.random()*1000%100)
    num2 = int(random.random()*1000%100)

    if(random.randint(0,15)):
        expire_at = 'NULL'
    else:
        expire_at = "'" + str(createTimeStamp(1600000000, 1650000000)) + "'"
    file1.write("INSERT INTO Users_permission VALUES('")
    file1.write(finalUsernames[random.randint(0, len(finalUsernames)-1)]+ "', " + str(random.randint(1,100)) +", '" + str(createTimeStamp(1600000000, 1650000000)) + "', " + expire_at + ", FALSE")
    file1.write(");\n")


file1.close()